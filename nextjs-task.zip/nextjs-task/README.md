# nextjs-task

here i have added the zip file and the document for the task

https://drive.google.com/drive/folders/12-1Y1Q0H4AtcX458AlxxPyqh-VbVNqhX?usp=sharing
