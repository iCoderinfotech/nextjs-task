(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_072828.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_072828.js",
  "chunks": [
    "static/chunks/node_modules_next_0766a2._.js",
    "static/chunks/app_page_49c625.js"
  ],
  "source": "dynamic"
});
